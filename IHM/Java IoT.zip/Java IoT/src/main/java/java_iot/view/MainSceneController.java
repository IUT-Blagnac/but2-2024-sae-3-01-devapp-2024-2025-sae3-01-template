package java_iot.view;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

public class MainSceneController implements Initializable {


	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

	
	

}
