package java_iot;

public class Main {
	public static void main(String[] args) {
		App.main2(args);
	}
}
